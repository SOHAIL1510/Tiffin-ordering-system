// Function to handle sidebar menu clicks
function handleSidebarMenuClick(event, anchor) {
    event.preventDefault(); // Prevent the default action of anchor click
    // Remove 'active' class from all sidebar menu items
    document.querySelectorAll('#sidebar .side-menu li').forEach(item => {
        item.classList.remove('active');
    });
    // Add 'active' class to the clicked menu item
    anchor.parentElement.classList.add('active');

    // Hide welcome message
    document.getElementById('welcome-msg').style.display = 'none';

    // Hide all dashboard sections
    document.querySelectorAll('.dashboard_main, .dashboard_main2, .meals').forEach(section => {
        section.style.display = 'none';
    });

    // Get the ID of the section to display based on the clicked menu item
    const sectionId = anchor.getAttribute('data-section');

    // Display the corresponding dashboard section
    document.getElementById(sectionId).style.display = 'block';
}

// Add event listener to handle sidebar menu clicks
document.querySelectorAll('#sidebar .side-menu a').forEach(item => {
    item.addEventListener('click', function(event) {
        handleSidebarMenuClick(event, item);
    });
});

// Function to handle sidebar menu clicks
// TOGGLE SIDEBAR
const menuBar = document.querySelector('#content nav .bx.bx-menu');
const sidebar = document.getElementById('sidebar');

menuBar.addEventListener('click', function () {
    sidebar.classList.toggle('hide');
});

// Other JavaScript code...

// Check if there are any JavaScript errors in the console
// Function to hide the second dashboard when the page loads
function hideSecondDashboard() {
    const secondDashboard = document.getElementById('dashboard_main2');
    if (secondDashboard) {
        secondDashboard.style.display = 'none';
    }
}

// Call the function to hide the second dashboard when the page loads
window.addEventListener('load', hideSecondDashboard);








const searchButton = document.querySelector('#content nav form .form-input button');
const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx');
const searchForm = document.querySelector('#content nav form');

searchButton.addEventListener('click', function (e) {
	if(window.innerWidth < 576) {
		e.preventDefault();
		searchForm.classList.toggle('show');
		if(searchForm.classList.contains('show')) {
			searchButtonIcon.classList.replace('bx-search', 'bx-x');
		} else {
			searchButtonIcon.classList.replace('bx-x', 'bx-search');
		}
	}
})





if(window.innerWidth < 768) {
	sidebar.classList.add('hide');
} else if(window.innerWidth > 576) {
	searchButtonIcon.classList.replace('bx-x', 'bx-search');
	searchForm.classList.remove('show');
}


window.addEventListener('resize', function () {
	if(this.innerWidth > 576) {
		searchButtonIcon.classList.replace('bx-x', 'bx-search');
		searchForm.classList.remove('show');
	}
})



const switchMode = document.getElementById('switch-mode');

switchMode.addEventListener('change', function () {
	if(this.checked) {
		document.body.classList.add('dark');
	} else {
		document.body.classList.remove('dark');
	}
})  
// Function to handle sidebar menu clicks
// Function to handle sidebar menu clicks
// Add event listener to handle sidebar menu clicks
document.querySelectorAll('#sidebar .side-menu a').forEach(item => {
	item.addEventListener('click', function(event) {
		handleSidebarMenuClick(event, item);
	});
});

// Function to handle sidebar menu clicks
function handleSidebarMenuClick(event, anchor) {
	event.preventDefault(); // Prevent the default action of anchor click
	// Remove 'active' class from all sidebar menu items
	document.querySelectorAll('#sidebar .side-menu li').forEach(item => {
		item.classList.remove('active');
	});
	// Add 'active' class to the clicked menu item
	anchor.parentElement.classList.add('active');

	// Hide welcome message
	document.getElementById('welcome-msg').style.display = 'none';

	// Hide all dashboard sections
	document.querySelectorAll('.dashboard_main, .dashboard_main2, .meals').forEach(section => {
		section.style.display = 'none';
	});

	// Get the ID of the section to display based on the clicked menu item
	const sectionId = anchor.getAttribute('data-section');

	// Display the corresponding dashboard section
	document.getElementById(sectionId).style.display = 'block';
}

function hideSecondDashboard() {
    const secondDashboard = document.getElementById('dashboard_main2');
    if (secondDashboard) {
        secondDashboard.style.display = 'none';
    }
}

// Call the function to hide the second dashboard when the page loads
window.addEventListener('load', hideSecondDashboard);


// Function to create the form
function createMealForm() {
	// Create a new div to contain the form
	var formOverlay = document.createElement('div');
	formOverlay.className = 'overlay';
	
	// Create the form element
	var form = document.createElement('form');
	form.id = 'productForm';
	form.enctype = 'multipart/form-data';
  
	// Add form fields
	form.innerHTML = `
		<div class="form-group">
			<label for="image">Image:</label>
			<input type="file" id="image" name="image" accept="image/*" required>
		</div>
		<div class="form-group">
			<label for="name">Name:</label>
			<input type="text" id="name" name="name" required>
		</div>
		<div class="form-group">
			<label for="price">Price:</label>
			<input type="number" id="price" name="price" step="0.01" required>
		</div>
		<div class="form-group">
			<label for="quantityLeft">Quantity Left:</label>
			<input type="number" id="quantityLeft" name="quantityLeft" required>
		</div>
		<div class="form-group">
			<label for="type">Type:</label>
			<select id="type" name="type" required>
				<option value="" disabled selected>Select Type</option>
				<option value="veg">Veg</option>
				<option value="non-veg">Non-Veg</option>
			</select>
		</div>
		<button type="submit">Submit</button>
	`;
  
	// Append the form to the formOverlay div
	formOverlay.appendChild(form);
  
	// Append the formOverlay to the document body
	document.body.appendChild(formOverlay);
  }
  
  // Event listener for Add Meal button
  document.getElementById('addMealButton').addEventListener('click', function() {
	createMealForm();
  });
  