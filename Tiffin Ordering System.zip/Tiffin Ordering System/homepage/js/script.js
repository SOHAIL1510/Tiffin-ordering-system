let navbar = document.querySelector('.navbar')
let navbar2=document.querySelector('.navbar2')

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    // navbar2.classList.toggle('active');
    loginForm.classList.remove('active');
    searchForm.classList.remove('active');
}
document.querySelector('#login-btn').onclick = () =>{
    navbar2.classList.toggle('active');
    // navbar.classList.toggle( 'active' );
    loginForm.classList.remove('active');
    searchForm.classList.remove('active');
}
 

let searchForm = document.querySelector('.search-form')

document.querySelector('#search-btn').onclick = () =>{
    searchForm.classList.toggle('active');
    navbar.classList.remove('active');
    navbar2.classList.remove('active');
    

    loginForm.classList.remove('active');
}

window.onscroll = () =>{
    navbar.classList.remove('active');
    navbar2.classList.remove('active');
    loginForm.classList.remove('active');
    searchForm.classList.remove('active');
}
 
var swiper = new Swiper(".review-slider", {
    loop:true,
    spaceBetween: 30,
    centeredSlides: true,
    autoplay: {
        delay: 5500,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".swiper-pagination",
    },
});
var swiper = new Swiper(".feature-slider", {
    loop:true,
    spaceBetween: 420,
    centeredSlides: true,
    autoplay: {
        delay: 2500,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".swiper-pagination",
    },
});


